package com.cg.pizzaorder.service;


import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;

public class PizzaOrderService implements IPizzaOrderService
{	
	
	static IPizzaOrderDAO ipd= new PizzaOrderDAO(); ;
	//The method to add the details in the map
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaException 
	{
		
		return ipd.placeOrder(customer,pizza);
		
		
	}
	@Override
	public PizzaOrder displayOrder(int orderid) throws PizzaException {
		// TODO Auto-generated method stub
		
		return ipd.displayOrder(orderid);
	}
	@Override
	public double calculatePrice(PizzaOrder pizza) {
		// TODO Auto-generated method stub
		return ipd.calculatePrice(pizza);
	}
	public boolean validateOrderID(int oid) {
		// TODO Auto-generated method stub
		return true;
	}
}
	
	//The method to get all the details from the map
	